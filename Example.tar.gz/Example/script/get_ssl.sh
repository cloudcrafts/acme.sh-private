#!/bin/bash

# Author: Lucky
# Date: 2024-07-01  
# Description: get ssl and deploy ssl
# Version: 1.0
# Usage: ./get_ssl.sh  --dns ali -d domain.com --ds "127.0.0.1 182.121.12.1 ...


check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: $1"
        exit 1
    fi
}

# load secret
__load_secret() {
    source ~/.$1/secret
}
# load deploy config
__load_deploy_config() {
    servers=$1
    domain=$2
    export DEPLOY_SSH_USER="root"
    export DEPLOY_SSH_SERVER="$servers"
    export DEPLOY_SSH_KEYFILE="/data/ssl/$domain/privkey2.pem"
    export DEPLOY_SSH_FULLCHAIN="/data/ssl/$domain/fullchain2.pem"
    export DEPLOY_SSH_CAFILE="/data/ssl/$domain/cert2.pem"
    export DEPLOY_SSH_REMOTE_CMD="nginx -s reload"

    # ssh server and mkdir -p /data/ssl/$domain
    IFS=' ' read -r -a server_array <<< "$servers"

    for s in "${server_array[@]}";do
        ssh $s "mkdir -p /data/ssl/$domain"
        check_status "ssh $s mkdir -p /data/ssl/$domain"
    done
}

# load cdn deploy config
__load_ali_cdn_deploy_config() {
    __load_secret "ali"
    export DEPLOY_ALI_CDN_DOMAIN="$server"
}

# load slb deploy config
__load_ali_slb_deploy_config() {
    __load_secret "ali"
    export Ali_Region="$1"
    export DEPLOY_ALI_SLB_ID="$2"
    export DEPLOY_ALI_SLB_PORT="$3"
}

__isEccKey() {
    __length="$1"

    case "$__length" in
    1024|2048|3072|4096|8192)
        return 0
	;;
    *)
        echo "ERROR: The RSA length \"$__length\" is invalid."
        exit 1
	;;
    esac
}

get_ssl() {
    dns=$1
    domain=$2
    caServer=$3
    keylenth=$4
    __load_secret $dns
    if [ -n "$keylenth" ];then
	__isEccKey $keylenth
    	~/.acme.sh/acme.sh --issue --dns dns_$dns -d $domain --server $caServer --keylength $keylenth
    else
    	~/.acme.sh/acme.sh --issue --dns dns_$dns -d $domain --server $caServer
    fi
}

deploy_ssl() {
    DEPLOY=$1
    server=$2
    domain=$3

    if [ -z "$server" ];then
        echo "deploy server is empty,skip deploy"
        return
    fi

    if [ "$DEPLOY" = "ali_cdn" ]; then
        __load_ali_cdn_deploy_config $server
    elif [ "$DEPLOY" = "ali_dcdn" ]; then
        __load_ali_cdn_deploy_config $server
    elif [ "$DEPLOY" = "ali_slb" ]; then
	if [[ -z "$ali_region" || -z "$port" ]];then
		echo "The ali_slb parameter is missing!"
		exit 1
	fi
        __load_ali_slb_deploy_config $ali_region $server $port
    elif [ "$DEPLOY" = "ssh" ]; then
        __load_deploy_config "$server" $domain
    fi 

    domain=$(echo $domain | sed 's/ //g')

    echo "deploying $domain to $server"
    ~/.acme.sh/acme.sh -d $domain --deploy --deploy-hook $DEPLOY
}

usage() {
    cat <<EOF
Usage: $0 [options]
       --dns: dns provider, ali, aws, dp. [optional], if not set, only deploy
       --ds: deploy servers, "ssh-server1 ssh-server2 ..." [required]
       --server: CA server, default is ZeroSSL letsencrypt [optional]
       -d: domain, domain.com [required]
       -h, --help: show help
       example: 
            ./get_ssl.sh  --dns ali -d domain.com --ds "ssh-server1 ssh-server2 ..."
            ./get_ssl.sh  -d domain.com --ds "ssh-server1 ssh-server2 ..."
EOF
    exit 1 
}



main() {
    while [ $# -gt 0 ]; do
        case $1 in
            --dns)
                dns=$2
                shift
                ;;
            -d)
                domain=$2
                shift
                ;;
            --ds)
                servers=$2
                shift
                ;;
            --server)
                caServer=$2
                shift
                ;;
            --deploy)
                deploy=$2
                shift
                ;;
            --keylength)
                keylenth=$2
                shift
                ;;
            --ali_region)
                ali_region=$2
                shift
                ;;
            --port)
                port=$2
                shift
                ;;
            -h|--help)
                usage
                ;;
            *)
                usage
                ;;
        esac
        shift
    done

    if [ -z "$domain" ] || [ -z "$servers" ]; then
        usage
    fi

    # check args, if not dns, only deploy
    if [ -n "$dns" ]; then
        get_ssl $dns $domain $caServer $keylenth
    fi

    if [ -n "$deploy" ]; then
	    deploy_ssl $deploy "$servers" $domain $ali_region $port
    fi
}
main "$@"
